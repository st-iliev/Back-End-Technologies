﻿using GardenConsoleAPI.Business;
using GardenConsoleAPI.Business.Contracts;
using GardenConsoleAPI.Data.Models;
using GardenConsoleAPI.DataAccess;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System.ComponentModel.DataAnnotations;

namespace GardenConsoleAPI.IntegrationTests.NUnit
{
    public class IntegrationTests
    {
        private TestPlantsDbContext dbContext;
        private IPlantsManager plantsManager;

        [SetUp]
        public void SetUp()
        {
            this.dbContext = new TestPlantsDbContext();
            this.plantsManager = new PlantsManager(new PlantsRepository(this.dbContext));
        }


        [TearDown]
        public void TearDown()
        {
            this.dbContext.Database.EnsureDeleted();
            this.dbContext.Dispose();
        }


        //positive test
        [Test]
        public async Task AddPlantAsync_ShouldAddNewPlant()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            // Act
            await plantsManager.AddAsync(newPlant);
            var plantDB = await dbContext.Plants.FirstOrDefaultAsync(s=> s.Id == newPlant.Id);
            // Assert
            Assert.IsNotNull(plantDB);
            Assert.AreEqual(newPlant.Id, plantDB.Id);
            Assert.AreEqual(newPlant.CatalogNumber, plantDB.CatalogNumber);
            Assert.AreEqual(newPlant.Name, plantDB.Name);
            Assert.AreEqual(newPlant.PlantType, plantDB.PlantType);
            Assert.AreEqual(newPlant.FoodType, plantDB.FoodType);
            Assert.AreEqual(newPlant.Quantity, plantDB.Quantity);
            Assert.AreEqual(newPlant.IsEdible, plantDB.IsEdible);
        }

        //Negative test
        [Test]
        public async Task AddPlantAsync_TryToAddPlantWithInvalidCredentials_ShouldThrowException()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337@@@!",
                Name = "Invalid Name Invalid Name Invalid Name Invalid Name Invalid Name",
                PlantType = "Test Test Test Test Test Test Test",
                FoodType = "Don't know, Don't know, Don't know, Don't know",
                Quantity = -1,
                IsEdible = true
            };
            // Act
            var ex = Assert.ThrowsAsync<ValidationException>(async () => await plantsManager.AddAsync(newPlant));
            // Assert
            Assert.AreEqual("Invalid plant!", ex.Message);

        }

        [Test]
        public async Task DeletePlantAsync_WithValidCatalogNumber_ShouldRemovePlantFromDb()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            // Act
            await plantsManager.DeleteAsync(newPlant.CatalogNumber);
            var plantDB = await dbContext.Plants.FirstOrDefaultAsync(s=> s.CatalogNumber == newPlant.CatalogNumber);
            // Assert
            Assert.IsNull(plantDB);
        }

        [Test]
        [TestCase(" ")]
        [TestCase(null)]
        public async Task DeletePlantAsync_TryToDeleteWithNullOrWhiteSpaceCatalogNumber_ShouldThrowException(string invalidCatalogNumber)
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            // Act
            var ex = Assert.ThrowsAsync<ArgumentException>(async () => await plantsManager.DeleteAsync(invalidCatalogNumber));
            // Assert
            Assert.AreEqual("Catalog number cannot be empty.", ex.Message);
        }

        [Test]
        public async Task GetAllAsync_WhenPlantsExist_ShouldReturnAllPlants()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            var newPlant1 = new Plant()
            {
                Id = 13371,
                CatalogNumber = "123456789012",
                Name = "Planta1",
                PlantType = "Best1",
                FoodType = "Don't know1",
                Quantity = 2,
                IsEdible = false
            };
            await plantsManager.AddAsync(newPlant);
            await plantsManager.AddAsync(newPlant1);
            // Act
            var plantDB = await plantsManager.GetAllAsync();

            // Assert
            Assert.IsNotNull(plantDB);
            Assert.AreEqual(plantDB.Count(), 2);
            Assert.AreEqual(newPlant.Id,plantDB.First().Id);
            Assert.AreEqual(newPlant.CatalogNumber, plantDB.First().CatalogNumber);
            Assert.AreEqual(newPlant.Name, plantDB.First().Name);
            Assert.AreEqual(newPlant.PlantType, plantDB.First().PlantType);
            Assert.AreEqual(newPlant.FoodType, plantDB.First().FoodType);
            Assert.AreEqual(newPlant.Quantity, plantDB.First().Quantity);
            Assert.AreEqual(newPlant.IsEdible, plantDB.First().IsEdible);
            Assert.AreEqual(newPlant1.Id, plantDB.Last().Id);
            Assert.AreEqual(newPlant1.CatalogNumber, plantDB.Last().CatalogNumber);
            Assert.AreEqual(newPlant1.Name, plantDB.Last().Name);
            Assert.AreEqual(newPlant1.PlantType, plantDB.Last().PlantType);
            Assert.AreEqual(newPlant1.FoodType, plantDB.Last().FoodType);
            Assert.AreEqual(newPlant1.Quantity, plantDB.Last().Quantity);
            Assert.AreEqual(newPlant1.IsEdible, plantDB.Last().IsEdible);

        }

        [Test]
        public async Task GetAllAsync_WhenNoPlantsExist_ShouldThrowKeyNotFoundException()
        {
            // Act
            var ex  = Assert.ThrowsAsync<KeyNotFoundException>(async () => await plantsManager.GetAllAsync());
            // Assert
            Assert.AreEqual("No plant found.", ex.Message);
        }

        [Test]
        public async Task SearchByFoodTypeAsync_WithExistingFoodType_ShouldReturnMatchingPlants()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            var newPlant1 = new Plant()
            {
                Id = 13371,
                CatalogNumber = "123456789012",
                Name = "Planta1",
                PlantType = "Best1",
                FoodType = "Don't know1",
                Quantity = 13,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            await plantsManager.AddAsync(newPlant1);
            // Act
            var result = await plantsManager.SearchByFoodTypeAsync(newPlant.FoodType);
            // Assert
            Assert.AreEqual(result.Count(), 1);
            Assert.AreEqual(newPlant.Id, result.First().Id);
            Assert.AreEqual(newPlant.CatalogNumber, result.First().CatalogNumber);
            Assert.AreEqual(newPlant.Name, result.First().Name);
            Assert.AreEqual(newPlant.PlantType, result.First().PlantType);
            Assert.AreEqual(newPlant.FoodType, result.First().FoodType);
            Assert.AreEqual(newPlant.Quantity, result.First().Quantity);
            Assert.AreEqual(newPlant.IsEdible, result.First().IsEdible);
        }

        [Test]
        public async Task SearchByFoodTypeAsync_WithNonExistingFoodType_ShouldThrowKeyNotFoundException()
        {
            // Arrange
            string invalidFoodType = "invalidType";
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            // Act
            var ex = Assert.ThrowsAsync<KeyNotFoundException>(() => plantsManager.SearchByFoodTypeAsync(invalidFoodType));
            // Assert
            Assert.AreEqual("No plant found with the given food type.", ex.Message);
        }

        [Test]
        public async Task GetSpecificAsync_WithValidCatalogNumber_ShouldReturnPlant()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            // Act
            var result = await plantsManager.GetSpecificAsync(newPlant.CatalogNumber);
            var plantDB = await dbContext.Plants.FirstOrDefaultAsync( s=> s.CatalogNumber == newPlant.CatalogNumber );
            // Assert
            Assert.IsNotNull(plantDB);
            Assert.AreEqual(newPlant.Id, result.Id);
            Assert.AreEqual(newPlant.CatalogNumber, result.CatalogNumber);
            Assert.AreEqual(newPlant.Name, result.Name);
            Assert.AreEqual(newPlant.PlantType, result.PlantType);
            Assert.AreEqual(newPlant.FoodType, result.FoodType);
            Assert.AreEqual(newPlant.Quantity, result.Quantity);
            Assert.AreEqual(newPlant.IsEdible, result.IsEdible);
        }

        [Test]
        public async Task GetSpecificAsync_WithInvalidCatalogNumber_ShouldThrowKeyNotFoundException()
        {
            // Arrange
            string invalidCatalogNumber = "invalidCatalogNumber";
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            // Act
            var ex = Assert.ThrowsAsync<KeyNotFoundException>(() => plantsManager.GetSpecificAsync(invalidCatalogNumber));
            // Assert
            Assert.AreEqual("No plant found with catalog number: invalidCatalogNumber", ex.Message);
        }

        [Test]
        public async Task UpdateAsync_WithValidPlant_ShouldUpdatePlant()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            }; 
            var newPlant1 = new Plant()
            {
                Id = 13317,
                CatalogNumber = "1111337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            await plantsManager.AddAsync(newPlant1);
            var updatedPlant = newPlant;
            updatedPlant.Name = "UPDATED NAME";
            // Act
            await plantsManager.UpdateAsync(updatedPlant);
            var plantDB = await dbContext.Plants.FirstOrDefaultAsync( s=> s.Name == updatedPlant.Name );
            // Assert
            Assert.IsNotNull(plantDB);
            Assert.AreEqual(updatedPlant.Id, plantDB.Id);
            Assert.AreEqual(updatedPlant.CatalogNumber, plantDB.CatalogNumber);
            Assert.AreEqual(updatedPlant.Name, plantDB.Name);
            Assert.AreEqual(updatedPlant.PlantType, plantDB.PlantType);
            Assert.AreEqual(updatedPlant.FoodType, plantDB.FoodType);
            Assert.AreEqual(updatedPlant.Quantity, plantDB.Quantity);
            Assert.AreEqual(updatedPlant.IsEdible, plantDB.IsEdible);
        }

        [Test]
        public async Task UpdateAsync_WithInvalidPlant_ShouldThrowValidationException()
        {
            // Arrange
            var newPlant = new Plant()
            {
                Id = 1337,
                CatalogNumber = "ABC1337BO056",
                Name = "Planta",
                PlantType = "Best",
                FoodType = "Don't know",
                Quantity = 1,
                IsEdible = true
            };
            await plantsManager.AddAsync(newPlant);
            // Act
            var ex = Assert.ThrowsAsync<ValidationException>(() => plantsManager.UpdateAsync(new Plant()));
            // Assert
            Assert.AreEqual("Invalid plant!", ex.Message);
        }
    }
}
