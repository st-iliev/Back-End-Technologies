﻿using ContactsConsoleAPI.Business;
using ContactsConsoleAPI.Business.Contracts;
using ContactsConsoleAPI.Data.Models;
using ContactsConsoleAPI.DataAccess;
using ContactsConsoleAPI.DataAccess.Contrackts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactsConsoleAPI.IntegrationTests.NUnit
{
    public class IntegrationTests
    {
        private TestContactDbContext dbContext;
        private IContactManager contactManager;

        [SetUp]
        public void SetUp()
        {
            this.dbContext = new TestContactDbContext();
            this.contactManager = new ContactManager(new ContactRepository(this.dbContext));
        }


        [TearDown]
        public void TearDown()
        {
            this.dbContext.Database.EnsureDeleted();
            this.dbContext.Dispose();
        }


        //positive test
        [Test]
        public async Task AddContactAsync_ShouldAddNewContact()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "1234567890",
                Email = "test@gmail.com",
                Gender = "Female",
                Contact_ULID = "13377331007"
            };

            // Act
            await contactManager.AddAsync(contact);
            var dbContact = await dbContext.Contacts.FirstOrDefaultAsync(s => s.Contact_ULID == contact.Contact_ULID);

            // Assert
            Assert.NotNull(dbContact);
            Assert.AreEqual(contact.FirstName, dbContact.FirstName);
            Assert.AreEqual(contact.LastName, dbContact.LastName);
            Assert.AreEqual(contact.Address, dbContact.Address);
            Assert.AreEqual(contact.Phone, dbContact.Phone);
            Assert.AreEqual(contact.Email, dbContact.Email);
            Assert.AreEqual(contact.Gender, dbContact.Gender);
            Assert.AreEqual(contact.Contact_ULID, dbContact.Contact_ULID);
        }

        //Negative test
        [Test]
        public async Task AddContactAsync_TryToAddContactWithInvalidCredentials_ShouldThrowException()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456789010415789",
                Email = "test@gmail.com",
                Gender = "NewModernGender",
                Contact_ULID = "133377331007"
            };
            // Act 
            var ex = Assert.ThrowsAsync<ValidationException>( async()=> await contactManager.AddAsync(contact));
            var actual = await dbContext.Contacts.FirstOrDefaultAsync(s => s.Contact_ULID == contact.Contact_ULID);
            // Assert
            Assert.IsNull(actual);
            Assert.AreEqual(ex.Message, "Invalid contact!");
        }

        [Test]
        public async Task DeleteContactAsync_WithValidULID_ShouldRemoveContactFromDb()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456789",
                Email = "test@gmail.com",
                Gender = "Female",
                Contact_ULID = "159753654975"
            };
            await contactManager.AddAsync(contact);

            // Act
            await contactManager.DeleteAsync(contact.Contact_ULID);
            var dbContact = await dbContext.Contacts.FirstOrDefaultAsync(s=> s.Contact_ULID == contact.Contact_ULID);

            //Assert
            Assert.IsNull(dbContact);
        }

        [Test]
        public async Task DeleteContactAsync_TryToDeleteWithNullOrWhiteSpaceULID_ShouldThrowException()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);

            // Act
            var ex = Assert.ThrowsAsync<ArgumentException>(async () => await contactManager.DeleteAsync(null));

            //Assert
            Assert.AreEqual(ex.Message, "ULID cannot be empty.");
        }

        [Test]
        public async Task GetAllAsync_WhenContactsExist_ShouldReturnAllContacts()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            var contact1 = new Contact()
            {
                FirstName = "Test1",
                LastName = "Testa1",
                Address = "HomeToYou1",
                Phone = "1234565681",
                Email = "test1@gmail.com",
                Gender = "Gender1",
                Contact_ULID = "14785741891"
            };
            await contactManager.AddAsync(contact);
            await contactManager.AddAsync(contact1);

            // Act
            var contacts = await contactManager.GetAllAsync();

            // Assert
            Assert.AreEqual(contacts.Count(),2);
            CollectionAssert.Contains(contacts, contact);
            CollectionAssert.Contains(contacts, contact1);
        }

        [Test]
        public async Task GetAllAsync_WhenNoContactsExist_ShouldThrowKeyNotFoundException()
        {
            // Act
            var ex = Assert.ThrowsAsync<KeyNotFoundException>(async () => await contactManager.GetAllAsync());

            // Assert
            Assert.AreEqual(ex.Message, "No contact found.");
        }

        [Test]
        public async Task SearchByFirstNameAsync_WithExistingFirstName_ShouldReturnMatchingContacts()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            // Act
            var contacts = await contactManager.SearchByFirstNameAsync(contact.FirstName);
            //Assert
            Assert.AreEqual(contact.FirstName,contacts.First().FirstName);
        }

        [Test]
        public async Task SearchByFirstNameAsync_WithNonExistingFirstName_ShouldThrowKeyNotFoundException()
        {
            // Arrange
            string invalidFirstName = "Goshee";
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            // Act
           var ex = Assert.ThrowsAsync<KeyNotFoundException>(async() => await contactManager.SearchByFirstNameAsync(invalidFirstName));

            // Assert
            Assert.AreEqual(ex.Message, "No contact found with the given first name.");
        }

        [Test]
        public async Task SearchByLastNameAsync_WithExistingLastName_ShouldReturnMatchingContacts()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            // Act
            var contacts = await contactManager.SearchByLastNameAsync(contact.LastName);
            //Assert
            Assert.AreEqual(contact.LastName, contacts.First().LastName);
        }

        [Test]
        public async Task SearchByLastNameAsync_WithNonExistingLastName_ShouldThrowKeyNotFoundException()
        {
            // Arrange
            string invalidLastName = "Ivanoveca";
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            // Act
            var ex = Assert.ThrowsAsync<KeyNotFoundException>(async () => await contactManager.SearchByLastNameAsync(invalidLastName));

            // Assert
            Assert.AreEqual(ex.Message, "No contact found with the given last name.");
        }

        [Test]
        public async Task GetSpecificAsync_WithValidULID_ShouldReturnContact()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            // Act
            var dbContact = await contactManager.GetSpecificAsync(contact.Contact_ULID);
            //Assert
            Assert.AreEqual(contact.Contact_ULID, dbContact.Contact_ULID);
        }

        [Test]
        public async Task GetSpecificAsync_WithInvalidULID_ShouldThrowKeyNotFoundException()
        {
            // Arrange
            string invalidULID = "159753654852";
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            // Act
            var ex = Assert.ThrowsAsync<KeyNotFoundException>(async () => await contactManager.GetSpecificAsync(invalidULID));

            // Assert
            Assert.AreEqual(ex.Message, $"No contact found with ULID: {invalidULID}");
        }

        [Test]
        public async Task UpdateAsync_WithValidContact_ShouldUpdateContact()
        {
            // Arrange
            var contact = new Contact()
            {
                FirstName = "Test",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574189"
            };
            await contactManager.AddAsync(contact);
            var contact1 = new Contact()
            {
                FirstName = "Test1",
                LastName = "Testa",
                Address = "HomeToYou",
                Phone = "123456568",
                Email = "test@gmail.com",
                Gender = "Gender",
                Contact_ULID = "1478574133"
            };
            // Act
            await contactManager.UpdateAsync(contact1);
            var dbContact = await dbContext.Contacts.FirstOrDefaultAsync( s=> s.Contact_ULID == contact1.Contact_ULID );
            // Assert
            Assert.AreEqual(dbContact.FirstName, contact1.FirstName);
        }

        [Test]
        public async Task UpdateAsync_WithInvalidContact_ShouldThrowValidationException()
        {
            // Act
            var ex = Assert.ThrowsAsync<ValidationException>(async () => await contactManager.UpdateAsync(new Contact()));

            // Assert
            Assert.AreEqual(ex.Message, "Invalid contact!");
        }
    }
}
